Requires Autohotkey to work. Autohotkey can be installed at https://www.autohotkey.com/

To use the script, simply execute it. When executed, it will detect the current volume 
and swap it between high and low. It will play the Discord Mute sound effect to let 
you know what volume level it was set to. Note that this sound will be heard on stream
too! If you prefer to not hear this sound, use the script called 
"Volume Control (quiet).ahk" instead.

Alternatively: If you prefer to use keyboard shortcuts / keybinds instead of running
the script to execute, use the file "Volume Control (keybind).ahk". After this script is
executed, pressing CTRL + ALT + G will toggle the Discord volume. To change this shortcut,
edit the 4th line of the script. Explanation here: https://www.autohotkey.com/docs/Hotkeys.htm

For instructions on how to use with Stream Deck, see "Stream Deck setup.png"